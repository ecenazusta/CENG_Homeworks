
public abstract class CarRentalSimulationApp <T> implements IDeque<T>, IList<T>, IQueue<T> {

	//Ecenaz Usta       300201042
	//Duygu Başeğmez	300201062
	
	@SuppressWarnings("static-access")
	public static void main(String[] args) {
	
		ProgramExecuter executer = new ProgramExecuter();
		executer.run();
	}
}

